package com.test.news.features.news.data.model

enum class NewsItemType {
    ADS,
    NEWS,
    PREMIUM_NEWS
}

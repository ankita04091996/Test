package com.test.news.features.news.data.model

data class NewsItemImage(val id: Int, var url: String)
